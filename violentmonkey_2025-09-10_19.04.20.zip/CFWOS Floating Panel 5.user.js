// ==UserScript==
// @name         CFWOS Floating Panel 5
// @namespace    chris.awos
// @version      5.0e(Report Viewer added)
// @description  Floating AWOS detail viewer with drag, resize, and persistent state
// @match        https://met.forces.gc.ca/english/airops/AWOS/*
// @grant        none
// @run-at       document-idle
// ==/UserScript==

/*function stylePwxDetail(){

    }
    function styleVisDetail(){

    }
    function styleRvrDetail(){

    }
    function styleTmpDetail(){

    }
    function styleWndDetail(){

    }
    function styleAltDetail(){

    }
    function styleAlmDetail(){

    }*/

(function () {
    'use strict';

    const PANEL_ID = 'awos-floating-panel';
    const CONTENT_ID = 'awos-panel-content';
    const CLOSE_ID = 'awos-panel-close';


    const STORAGE_URL_KEY = 'awos-last-detail-url';
    const STORAGE_SNAPSHOT_KEY = 'awos-last-panel-snapshot';
    const STORAGE_TIMESTAMP_KEY = 'awos-last-timestamp';
    const STORAGE_POSITION_KEY = 'awos-panel-position';
    const STORAGE_SIZE_KEY = 'awos-panel-size';
    const REPORT_URL_KEY = 'awos-report-url';
    const REPORT_SNAPSHOT_KEY = 'awos-report-snapshot';
    const REPORT_TIMESTAMP_KEY = 'awos-report-timestamp';

    function getCurrentUtcTimestamp() {
      const now = new Date();
      const pad = (n) => n.toString().padStart(2, '0');
      return `${now.getUTCFullYear()}${pad(now.getUTCMonth() + 1)}${pad(now.getUTCDate())}${pad(now.getUTCHours())}${pad(now.getUTCMinutes())}`;
    }
    function getLatestHourlyTimestamp() {
      const now = new Date();
      now.setUTCMinutes(0, 0, 0); // snap to top of the hour
      const pad = (n) => n.toString().padStart(2, '0');
      return `${now.getUTCFullYear()}${pad(now.getUTCMonth() + 1)}${pad(now.getUTCDate())}${pad(now.getUTCHours())}00`;
    }

    const id = 'CYTR'
    const atime = getLatestHourlyTimestamp()

    const AWOS_BASE_URL = 'https://met.forces.gc.ca/english/airops/AWOS/';
    const timestamp = new Date().toISOString();

    let isDragging = false;
    let offsetX = 0;
    let offsetY = 0;

    function createPanel(updatedText = '') {
        if (document.getElementById(PANEL_ID)) return;

        const panel = document.createElement('div');
        panel.id = PANEL_ID;
        Object.assign(panel.style, {
            position: 'fixed',
            background: '#fff',
            border: '1px solid #ccc',
            boxShadow: '0 0 10px rgba(0,0,0,0.3)',
            zIndex: '9999',
            display: 'flex',
            flexDirection: 'column',
            overflow: 'auto',
            minWidth: '300px',
            minHeight: '150px',
            padding: '10px'
        });

        // Restore position and size
        const savedPos = JSON.parse(localStorage.getItem(STORAGE_POSITION_KEY));
        const savedSize = JSON.parse(localStorage.getItem(STORAGE_SIZE_KEY));
        panel.style.top = savedPos?.top || '20px';
        panel.style.left = savedPos?.left || '20px';
        panel.style.width = savedSize?.width || '400px';
        panel.style.height = savedSize?.height || '600px';

        // Title bar
        const titleBar = document.createElement('div');
        titleBar.id = `awos-panel-title`;
        Object.assign(titleBar.style, {
            background: '#0077cc',
            color: 'white',
            padding: '6px 10px',
            fontWeight: 'bold',
            display: 'flex',
            flexWrap: 'nowrap',
            overflow: 'hidden',
            justifyContent: 'space-between',
            alignItems: 'center',
            cursor: 'move'
        });

        // Title text
        const titleText = document.createElement('span');
        titleText.id = 'awos-panel-title-text';
        titleText.textContent = `${updatedText}`;

        // Close button
        const closeBtn = document.createElement('button');
        closeBtn.id = CLOSE_ID;
        closeBtn.textContent = '×';

        Object.assign(closeBtn.style, {
            fontSize: '20px',
            border: 'none',
            background: 'transparent',
            color: 'white',
            cursor: 'pointer',
            marginLeft: 'auto', // Pushes it to the right
            padding: '0 6px',
            lineHeight: '1',
            display: 'inline-block'
        });

        closeBtn.onclick = () => {
            panel.remove();
            window.__awosReportViewerSpawned = false;
            localStorage.removeItem(STORAGE_URL_KEY);
            localStorage.removeItem(STORAGE_SNAPSHOT_KEY);
            localStorage.removeItem(STORAGE_TIMESTAMP_KEY);

            localStorage.removeItem(REPORT_URL_KEY);
            localStorage.removeItem(REPORT_SNAPSHOT_KEY);
            localStorage.removeItem(REPORT_TIMESTAMP_KEY);

            localStorage.removeItem('awos-debug-snapshot');
            localStorage.removeItem('awos-debug-active');
            localStorage.removeItem('awos-debug-style');

            Logger.info('Floater closed and snapshot cleared.');
        };

        let isDragging = false, offsetX = 0, offsetY = 0;

        titleBar.addEventListener('mousedown', (e) => {
            isDragging = true;
            const rect = panel.getBoundingClientRect();
            offsetX = e.clientX - rect.left;
            offsetY = e.clientY - rect.top;
            document.body.style.userSelect = 'none';
        });

        document.addEventListener('mousemove', (e) => {
            if (!isDragging) return;
            panel.style.left = `${e.clientX - offsetX}px`;
            panel.style.top = `${e.clientY - offsetY}px`;
            localStorage.setItem(STORAGE_POSITION_KEY, JSON.stringify({
                top: panel.style.top,
                left: panel.style.left
            }));
        });

        document.addEventListener('mouseup', () => {
            isDragging = false;
            document.body.style.userSelect = '';
        });

        // Content area
        const content = document.createElement('div');
        content.id = CONTENT_ID;
        Object.assign(content.style, {
            flex: '1',
            overflowY: 'auto',
            padding: '10px'
        });

        const style = document.createElement('style');
        style.textContent = `
          #awos-floating-panel {
            font-family: Arial, sans-serif;
            font-size: 15px;
            color: #333;
          }

          #awos-detail-container {
            border: 2px solid #0077cc;
            padding: 12px;
            margin: 10px 0;
            background-color: #f9f9f9;
            font-family: monospace;
            font-size: 0.85em;
            overflow-x: auto;
          }

          .awos-detail-header {
            font-weight: bold;
            font-size: 1.1em;
            margin-bottom: 8px;
            color: #0055aa;
          }

          .awos-cloud-table,
          .awos-summary-table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 16px;
          }

          th, td {
            border: 1px solid #ccc;
            padding: 4px 6px;
            text-align: center;
          }

          .awos-cloud-table thead {
            background-color: #f0f0f0;
          }

          .awos-summary-table thead {
            background-color: #e0e0ff;
          }

          .awos-detail-header {
          font-weight: bold;
          font-size: 1.1em;
          margin-bottom: 10px;
          color: #0055aa;
        }

        .awos-detail-container table {
          border-collapse: collapse;
          margin-bottom: 20px;
          width: 100%;
        }

        .awos-detail-container th, .awos-detail-container td {
          border: 1px solid #ccc;
          padding: 4px 8px;
          text-align: left;
        }

        `;

        document.head.appendChild(style); // ✅ Correctly injects styles
        document.body.appendChild(panel); // ✅ Adds your floating panel


        panel.appendChild(titleBar);
        titleBar.appendChild(titleText);
        titleBar.appendChild(closeBtn);
        panel.appendChild(content);

        //Restore Block
        setTimeout(() => {
            const floaterSnapshot = JSON.parse(localStorage.getItem('floaterSnapshot'));
            if (floaterSnapshot) {
                const { savedWidth, savedHeight, windowHeight } = floaterSnapshot;

                const safeHeight = Math.min(savedHeight, window.innerHeight - 50);
                panel.style.width = `${savedWidth}px`;
                panel.style.height = `${safeHeight}px`;

                panel.style.maxHeight = `${window.innerHeight - 50}px`;
                panel.style.overflow = 'hidden';


                // Optional: restore position if saved
                if (floaterSnapshot.left !== undefined && floaterSnapshot.top !== undefined) {
                    panel.style.left = `${floaterSnapshot.left}px`;
                    panel.style.top = `${floaterSnapshot.top}px`;
                    panel.style.position = 'fixed';
                }
            }

            const savedSize = localStorage.getItem(STORAGE_SIZE_KEY);
            if (savedSize) {
                try {
                    const { width, height } = JSON.parse(savedSize);
                    const safeHeight = Math.min(parseInt(height), window.innerHeight - 50);
                    panel.style.width = width;
                    panel.style.height = `${safeHeight}px`;


                    // Delay logging until panel is styled
                    requestAnimationFrame(() => {
                        const rect = panel.getBoundingClientRect();
                        console.log('Restoring floater size:', {
                            savedWidth: width,
                            savedHeight: height,
                            computedWidth: rect.width,
                            computedHeight: rect.height,
                            windowHeight: window.innerHeight
                        });
                    });
                } catch (e) {
                    console.warn('Invalid size data:', e);
                }
            }

        }, 0);

        // Save Block on mouseup
        panel.addEventListener('mouseup', () => {
            if (document.body.contains(panel)) {
                const rect = panel.getBoundingClientRect();
                const floaterSnapshot = {
                    styleWidth: panel.style.width,
                    styleHeight: panel.style.height,
                    computedWidth: rect.width,
                    computedHeight: rect.height,
                    windowHeight: window.innerHeight,
                    savedWidth: rect.width,
                    savedHeight: rect.height,
                    left: rect.left,
                    top: rect.top
                };

                // Clamp to viewport
                const clampedWidth = Math.min(rect.width, window.innerWidth - rect.left);
                const clampedHeight = Math.min(rect.height, window.innerHeight - rect.top);

                console.log('Saving floater size:', {
                    clampedWidth,
                    clampedHeight,
                    windowHeight: window.innerHeight
                });

                localStorage.setItem('floaterSnapshot', JSON.stringify(floaterSnapshot));
                localStorage.setItem(STORAGE_SIZE_KEY, JSON.stringify({
                    width: `${clampedWidth}px`,
                    height: `${clampedHeight}px`
                }));
            }
        });

        // Edge resizers
        ['top', 'right', 'bottom', 'left'].forEach(edge => {
            const resizer = document.createElement('div');
            Object.assign(resizer.style, {
                position: 'absolute',
                zIndex: '10000',
                background: 'transparent',
                pointerEvents: 'auto',
                [edge]: '0',
                cursor: {
                    top: 'n-resize',
                    bottom: 's-resize',
                    left: 'w-resize',
                    right: 'e-resize'
                }[edge]

            });
            if (edge === 'top' || edge === 'bottom') {
                resizer.style.left = '0';
                resizer.style.width = '80%';
                resizer.style.height = '6px';
            } else {
                resizer.style.top = '0';
                resizer.style.height = '80%';
                resizer.style.width = '6px';
            }
            panel.appendChild(resizer);

            resizer.addEventListener('mousedown', (e) => {
                e.preventDefault();
                const iframe = panel.querySelector('iframe');
                if (iframe) iframe.style.pointerEvents = 'none';
                const startX = e.clientX;
                const startY = e.clientY;
                const startWidth = panel.offsetWidth;
                const startHeight = panel.offsetHeight;
                const startTop = panel.offsetTop;
                const startLeft = panel.offsetLeft;

                function onMouseMove(ev) {
                    if (edge === 'right') {
                        panel.style.width = `${startWidth + (ev.clientX - startX)}px`;
                    } else if (edge === 'bottom') {
                        panel.style.height = `${startHeight + (ev.clientY - startY)}px`;
                    } else if (edge === 'left') {
                        const newWidth = startWidth - (ev.clientX - startX);
                        const newLeft = startLeft + (ev.clientX - startX);
                        panel.style.width = `${newWidth}px`;
                        panel.style.left = `${newLeft}px`;
                    } else if (edge === 'top') {
                        const newHeight = startHeight - (ev.clientY - startY);
                        const newTop = startTop + (ev.clientY - startY);
                        panel.style.height = `${newHeight}px`;
                        panel.style.top = `${newTop}px`;
                    }
                }

                function onMouseUp() {
                    document.removeEventListener('mousemove', onMouseMove);
                    document.removeEventListener('mouseup', onMouseUp);
                    document.removeEventListener('mouseup', saveFloaterSizeOnce);
                }
                document.addEventListener('mousemove', onMouseMove);
                document.addEventListener('mouseup', onMouseUp);
            });
        });

        const cornerResizers = [
            { name: 'top-left', cursor: 'nw-resize', top: '0', left: '0' },
            { name: 'top-right', cursor: 'ne-resize', top: '0', right: '0' },
            { name: 'bottom-left', cursor: 'sw-resize', bottom: '0', left: '0' },
            { name: 'bottom-right', cursor: 'se-resize', bottom: '0', right: '0' } // already exists, but we’ll unify logic
        ];
        cornerResizers.forEach(corner => {
            const resizer = document.createElement('div');
            Object.assign(resizer.style, {
                position: 'absolute',
                width: '12px',
                height: '12px',
                cursor: corner.cursor,
                zIndex: '10001',
                background: 'transparent',
                ...corner
            });
            panel.appendChild(resizer);

            resizer.addEventListener('mousedown', (e) => {
                e.preventDefault();
                const iframe = panel.querySelector('iframe');
                if (iframe) iframe.style.pointerEvents = 'none';
                const startX = e.clientX;
                const startY = e.clientY;
                const startWidth = panel.offsetWidth;
                const startHeight = panel.offsetHeight;
                const startTop = panel.offsetTop;
                const startLeft = panel.offsetLeft;

                function onMouseMove(ev) {
                    const dx = ev.clientX - startX;
                    const dy = ev.clientY - startY;

                    if (corner.name.includes('right')) {
                        panel.style.width = `${startWidth + dx}px`;
                    }
                    if (corner.name.includes('left')) {
                        const newWidth = startWidth - dx;
                        if (newWidth > 300) {
                            panel.style.width = `${newWidth}px`;
                            panel.style.left = `${startLeft + dx}px`;
                        }
                    }
                    if (corner.name.includes('bottom')) {
                        panel.style.height = `${startHeight + dy}px`;
                    }
                    if (corner.name.includes('top')) {
                        const newHeight = startHeight - dy;
                        if (newHeight > 150) {
                            panel.style.height = `${newHeight}px`;
                            panel.style.top = `${startTop + dy}px`;
                        }
                    }
                }

                function onMouseUp() {
                    document.removeEventListener('mousemove', onMouseMove);
                    document.removeEventListener('mouseup', onMouseUp);
                    localStorage.setItem(STORAGE_SIZE_KEY, JSON.stringify({
                        width: panel.offsetWidth,
                        height: panel.offsetHeight
                    }));
                    localStorage.setItem(STORAGE_POSITION_KEY, JSON.stringify({
                        top: panel.style.top,
                        left: panel.style.left
                    }));
                }

                document.addEventListener('mousemove', onMouseMove);
                document.addEventListener('mouseup', onMouseUp);
            });
        });

    return panel;

    }

    function shiftTime(atime, hours) {
      if (!atime || typeof atime !== 'string' || atime.length !== 12) {
        console.warn('[AWOS Core] Invalid atime passed to shiftTime:', atime);
        return null;
      }

      const year = atime.slice(0, 4);
      const month = atime.slice(4, 6);
      const day = atime.slice(6, 8);
      const hour = atime.slice(8, 10);
      const minute = atime.slice(10, 12);

      const date = new Date(`${year}-${month}-${day}T${hour}:${minute}:00Z`);
      date.setHours(date.getHours() + hours);

      const pad = (n) => n.toString().padStart(2, '0');
      return `${date.getUTCFullYear()}${pad(date.getUTCMonth() + 1)}${pad(date.getUTCDate())}${pad(date.getUTCHours())}${pad(date.getUTCMinutes())}`;
    }
    function getCurrentUtcTimestamp() {
      const now = new Date();
      const pad = (n) => n.toString().padStart(2, '0');
      return `${now.getUTCFullYear()}${pad(now.getUTCMonth() + 1)}${pad(now.getUTCDate())}${pad(now.getUTCHours())}${pad(now.getUTCMinutes())}`;
    }
    function getLatestHourlyTimestamp() {
      const now = new Date();
      now.setUTCMinutes(0, 0, 0); // snap to top of the hour
      const pad = (n) => n.toString().padStart(2, '0');
      return `${now.getUTCFullYear()}${pad(now.getUTCMonth() + 1)}${pad(now.getUTCDate())}${pad(now.getUTCHours())}00`;
    }
    function forcePageReload() {
          window.onbeforeunload = null;
          window.onunload = null;
          window.location.reload(); // ✅ standard reload
          //location.href = location.href;
    }
    function saveFloaterSizeOnce() {
        const rect = panel.getBoundingClientRect();
        const clampedWidth = Math.min(rect.width, window.innerWidth - rect.left);
        const clampedHeight = Math.min(rect.height, window.innerHeight - rect.top);

        panel.style.width = `${clampedWidth}px`;
        panel.style.height = `${clampedHeight}px`;

        localStorage.setItem(STORAGE_SIZE_KEY, JSON.stringify({
            width: `${clampedWidth}px`,
            height: `${clampedHeight}px`
        }));

        document.removeEventListener('mouseup', saveFloaterSizeOnce);
    }
    function extractUpdatedTimestamp(rawHTML) {
        const parser = new DOMParser();
        const doc = parser.parseFromString(rawHTML, 'text/html');
        const abbr = doc.querySelector('abbr.timepopup');
        return abbr ? `Updated: ${abbr.textContent.trim()}` : '';
    }
    function styleButton(btn, bgColor, overrides = {}) {
      Object.assign(btn.style, {
        padding: '6px 12px',
        fontSize: '13px',
        color: '#fff',
        border: 'none',
        borderRadius: '4px',
        cursor: 'pointer',
        fontFamily: '"Segoe UI", sans-serif',
        boxShadow: 'rgba(0, 0, 0, 0.15) 0px 1px 4px',
        whiteSpace: 'nowrap',
        flex: '0 0 auto',
        background: bgColor,
        ...overrides // apply custom styles
      });
    }

    async function extractAwosStationsFromSelectorPage() {
      const response = await fetch('https://met.forces.gc.ca/english/airops/AWOS/');
      const html = await response.text();
      const parser = new DOMParser();
      const doc = parser.parseFromString(html, 'text/html');

      const checkboxes = doc.querySelectorAll('input[type="checkbox"][name="id"]');
      const stations = [];

      checkboxes.forEach(cb => {
        const icao = cb.value?.trim();
        const label = cb.nextElementSibling?.textContent?.trim();
        if (icao && /^[A-Z]{4}$/.test(icao)) {
          stations.push({
            icao,
            label,
            url: `https://met.forces.gc.ca/english/airops/AWOS/?id=${icao}`
          });
        }
      });

      return stations;
    }
    async function updateAwosSelectorContent(contentId) {
      const content = document.getElementById(contentId);
      if (!content) return;

      content.innerHTML = ''; // Clear previous content
      const stations = await extractAwosStationsFromSelectorPage();

      stations.forEach(({ icao, label, url }) => {
        const btn = document.createElement('button');
        btn.textContent = `${icao} – ${label}`;
        styleButton(btn, '#0f0', {
          color: '#000',
          marginBottom: '4px',
          padding: '4px 8px',
          fontSize: '13px',
          fontWeight: 'normal',
          width: '100%',
          textAlign: 'left'
        });

        btn.onclick = () => window.open(url, '_blank');
        content.appendChild(btn);
      });
    }
    async function renderAwosSelectorPanel() {
      const stations = await extractAwosStationsFromSelectorPage();
      const panel = createPanel('AWOS Station Selector');
      panel.style.cssText += `
        width: 408px;
        height: 859px;
        max-height: 859px;
        overflow-y: auto;
        resize: none;
      `;

      stations.forEach(({ icao, label, url }) => {
        const btn = document.createElement('button');
        btn.textContent = `${icao} – ${label}`;
        styleButton(btn, '#0078D4', {
          marginBottom: '4px',
          padding: '4px 8px',
          fontSize: '13px',
          fontWeight: 'normal',
          width: '100%',
          textAlign: 'left'
        });

        btn.onclick = () => window.open(url, '_blank');
        panel.appendChild(btn);
      });
    }

    window.renderAwosSelectorPanel = renderAwosSelectorPanel;

    function createReportNavBar(id, atime, contentEl, panelEl) {
      const nav = document.createElement('div');
      nav.style.cssText = 'display:flex;justify-content:space-between;margin-bottom:10px;';

      const prevHourBtn = document.createElement('button');
      prevHourBtn.textContent = '⟵ Previous Hour';
      prevHourBtn.onclick = () => {
        const newTime = shiftTime(atime, -1);
        loadReportInto(contentEl, id, newTime);
        atime = newTime;
      };

      const prevSpecialBtn = document.createElement('button');
      prevSpecialBtn.textContent = '⟵ Previous Special';
      prevSpecialBtn.onclick = () => {
        findPreviousSpecialReport(id, atime, (newTime, html) => {
          if (newTime) {
            atime = newTime;
            contentEl.innerHTML = html;
          } else {
            contentEl.innerHTML = 'No recent special report found.';
          }
        });
      };

      const nextBtn = document.createElement('button');
      nextBtn.textContent = 'Next ⟶';
      nextBtn.onclick = () => {
        const newTime = shiftTime(atime, 2);
        loadReportInto(contentEl, id, newTime);
        atime = newTime;
      };

      const latestBtn = document.createElement('button');
      latestBtn.textContent = '🕒 Latest';
      latestBtn.onclick = () => {
        panelEl.remove(); // Close the floating viewer
        forcePageReload();
      };

      nav.appendChild(prevHourBtn);
      nav.appendChild(prevSpecialBtn);
      nav.appendChild(nextBtn);
      nav.appendChild(latestBtn);
      return nav;
    }
    function saveReportSnapshot(content, url) {

      if (window.__awosReportViewerSpawned) {
        try {
          localStorage.setItem(REPORT_URL_KEY, url);
          localStorage.setItem(REPORT_SNAPSHOT_KEY, content.innerHTML);
          localStorage.setItem(REPORT_TIMESTAMP_KEY, new Date().toISOString());
          Logger.info('[Report Viewer] Snapshot saved.');
        } catch (e) {
          Logger.error('[Report Viewer] Failed to save snapshot:', e);
        }
      }
    }
    function updateReportTitleBar(updatedText, isSnapshot = false) {
        const titleText = document.getElementById('awos-panel-title-text');
        const titleBar = document.getElementById('awos-panel-title');
        if (!titleText || !titleBar) return;

        titleText.textContent = `AWOS Report Viewer. last updated: ${updatedText ? ' — ' + updatedText : ''}`;
        titleBar.style.background = isSnapshot ? '#ffcc00' : '#0077cc';
        titleBar.style.color = isSnapshot ? '#000' : 'white';

        titleBar.title = isSnapshot ? 'Snapshot restored — data may be outdated' : '';
    }
    function restoreReportSnapshot() {
      if (window.self !== window.top) {
          Logger.info('[Report Viewer] Skipping spawn — running inside iframe.');
          return;
      }
      const url = `https://met.forces.gc.ca/english/airops/AWOS/?id=${id}&atime=${atime}`;
      const snapshot = localStorage.getItem(REPORT_SNAPSHOT_KEY);
      const restoredTimestamp = localStorage.getItem(REPORT_TIMESTAMP_KEY) || '';


      if (!snapshot) {
        Logger.info('[Report Viewer] No snapshot found in localStorage. Skipping restore.');
        return;
      }

      window.requestAnimationFrame(() => {
        setTimeout(() => {
          Logger.info(`[Report Viewer] Restoring snapshot from ${restoredTimestamp}`);
          const restoredPanel = createPanel('AWOS Report Viewer');
          updateReportTitleBar(restoredTimestamp, true)
          const content = document.getElementById(CONTENT_ID);
          if (content) {
            content.innerHTML = snapshot;
            const urlParams = new URLSearchParams(url.split('?')[1]);
            const id = urlParams.get('id');
            const atime = urlParams.get('atime');

            const navBar = createReportNavBar(id, atime, content, restoredPanel);
            restoredPanel.insertBefore(navBar, content);
          }
        }, 300);
      });
    }
    function openReportViewer() {
        if (window.self !== window.top) {
          Logger.info('[Report Viewer] Skipping spawn — running inside iframe.');
          return;
        }

        if (window.__awosReportViewerSpawned) {
          console.log('[Report Viewer] Already spawned — skipping.');
          return;
        }
        window.__awosReportViewerSpawned = true;

        const url = `https://met.forces.gc.ca/english/airops/AWOS/?id=${id}&atime=${atime}`;
        const viewerPanel = createPanel("AWOS Report Viewer");


        const panelID = viewerPanel.querySelector('#awos-floating-panel');


        if (!viewerPanel) return;

        const content = viewerPanel.querySelector(`#${CONTENT_ID}`);
        if (!content) return;

        content.style.cssText = `
          display: flex;
          flex-direction: column;
          flex: 1;
          padding: 0;
          margin: 0;
          overflow: hidden;
        `;

        const navBar = createReportNavBar(id, atime, content, viewerPanel);
        viewerPanel.insertBefore(navBar, content);
        localStorage.setItem('awos-report-active', 'true');


        const iframe = document.createElement('iframe');
        iframe.src = url;
        iframe.style.cssText = `
          flex: 1;
          width: 100%;
          height: 100%;
          border: none;
        `;
        content.appendChild(iframe);

        if (panelID && iframe && navBar) {
          console.log('[Report Viewer] Panel already initialized — skipping spawn.');
          return;
        }

        saveReportSnapshot(content, url);

        Logger.info(`AWOS Report Viewer opened to ${url}`);
    }

    window.openReportViewer = openReportViewer;

    function updateDebugContent() {
        const content = document.getElementById('awos-panel-content');
        if (!content) return;

        const status = window.getAwosRefreshStatus?.() || {};
        content.innerHTML = `
            <strong>AWOS Debug Panel</strong><br><br>
            Core Version: 6.0<br>
            Refresh: ${status.enabled ? 'ON' : 'OFF'} (${status.secondsLeft}s)<br>
            Floater: ${document.querySelector('#floater-btn') ? 'Injected' : 'Missing'}<br>
            TopBar: ${window.awosTopBar ? 'Available' : 'Not Found'}<br>
            Host: ${location.hostname}<br>
            Time: ${new Date().toLocaleTimeString()}<br>
        `;

        try {
            const content = document.getElementById('awos-panel-content');
            if (content) {
                localStorage.setItem('awos-debug-snapshot', content.innerHTML);
                localStorage.setItem('awos-debug-active', 'true');
                localStorage.setItem('awos-debug-style', 'true');
                console.log('[Debug Panel] Snapshot saved.');
            }
        } catch (e) {
            console.warn('[Debug Panel] Failed to save snapshot:', e);
        }

    }
    function openDebugPanel() {
        const panelId = 'awos-floating-panel';
        const contentId = 'awos-panel-content';
        // If panel already exists, just update content
        const existingPanel = document.getElementById(panelId);
        if (existingPanel) {
            const panel = document.getElementById('awos-floating-panel');
            const content = document.getElementById('awos-panel-content');
            const titleBar = document.getElementById('awos-panel-title');

            if (panel && content) {
                panel.style.background = '#000';
                panel.style.color = '#0f0';
                panel.style.border = '1px solid #0f0';
                panel.style.fontFamily = 'monospace';
                panel.style.fontSize = '13px';
                panel.style.boxShadow = '0 0 12px rgba(0,255,0,0.3)';

                content.style.background = '#000';
                content.style.color = '#0f0';
                content.style.padding = '10px';
                content.style.overflowY = 'auto';

              if (titleBar) {
                  titleBar.style.background = '#0f0';
                  titleBar.style.color = '#000';
              }

            }
            updateDebugContent();
            return;
        }

        // Create panel with title "Debug Panel"
        createPanel('Debug Panel');

        const panel = document.getElementById('awos-floating-panel');
        const content = document.getElementById('awos-panel-content');
        const titleBar = document.getElementById('awos-panel-title');

        if (panel && content) {
            panel.style.background = '#000';
            panel.style.color = '#0f0';
            panel.style.border = '1px solid #0f0';
            panel.style.fontFamily = 'monospace';
            panel.style.fontSize = '13px';
            panel.style.boxShadow = '0 0 12px rgba(0,255,0,0.3)';

            content.style.background = '#000';
            content.style.color = '#0f0';
            content.style.padding = '10px';
            content.style.overflowY = 'auto';

          if (titleBar) {
              titleBar.style.background = '#0f0';
              titleBar.style.color = '#000';
          }

        }

        updateDebugContent();
    }
    function restoreDebugPanel() {
        const snapshot = localStorage.getItem('awos-debug-snapshot');
        const isActive = localStorage.getItem('awos-debug-active') === 'true';
        const isDebugStyled = localStorage.getItem('awos-debug-style') === 'true';
        if (!snapshot || !isActive) return;

        console.log('[Debug Panel] Restoring from snapshot...');
        createPanel('Debug Panel');

        const panel = document.getElementById('awos-floating-panel');
        const content = document.getElementById('awos-panel-content');
        const titleBar = document.getElementById('awos-panel-title');
        const titleText = document.getElementById('awos-panel-title-text');

        if (panel && content && titleBar && titleText) {
            content.innerHTML = snapshot;

            if (isDebugStyled) {
                panel.style.background = '#000';
                panel.style.color = '#0f0';
                panel.style.border = '1px solid #0f0';
                panel.style.fontFamily = 'monospace';
                panel.style.fontSize = '13px';
                panel.style.boxShadow = '0 0 12px rgba(0,255,0,0.3)';

                content.style.background = '#000';
                content.style.color = '#0f0';
                content.style.padding = '10px';
                content.style.overflowY = 'auto';
                content.style.fontFamily = 'monospace';

                titleBar.style.background = '#0f0';
                titleBar.style.color = '#000';
                titleText.textContent = 'AWOS Debug Panel';
                titleText.style.fontFamily = 'monospace';
            }
        }
    }

    window.openDebugPanel = openDebugPanel;

    function updateDetailTitleBar(updatedText, isSnapshot = false) {
        const titleText = document.getElementById('awos-panel-title-text');
        const titleBar = document.getElementById('awos-panel-title');
        if (!titleText || !titleBar) return;

        titleText.textContent = `AWOS Detail Viewer${updatedText ? ' — ' + updatedText : ''}`;
        titleBar.style.background = isSnapshot ? '#ffcc00' : '#0077cc';
        titleBar.style.color = isSnapshot ? '#000' : 'white';
        titleBar.title = isSnapshot ? 'Snapshot restored — data may be outdated' : '';
    }
    function saveDetailSnapshot(content) {
        try {
            localStorage.setItem(STORAGE_SNAPSHOT_KEY, content.innerHTML);
            Logger.info('Snapshot saved.');
        } catch (e) {
            Logger.error('[Detail Viewer] Failed to save snapshot:', e);
        }
    }
    function restoreDetailSnapshot() {
        const snapshot = localStorage.getItem(STORAGE_SNAPSHOT_KEY);
        const restoredTimestamp = localStorage.getItem(STORAGE_TIMESTAMP_KEY) || '';
        if (!snapshot) {
            Logger.info('[Detail Viewer] No floater snapshot found in localStorage. Skipping restore.');
            return;
        }

        window.requestAnimationFrame(() => {
            setTimeout(() => {
                Logger.info(`[Detail Viewer] Restoring floater from ${restoredTimestamp}`);
                createPanel(restoredTimestamp);
                updateDetailTitleBar(restoredTimestamp, true)
                const content = document.getElementById(CONTENT_ID);
                if (content) content.innerHTML = snapshot;
            }, 300);
        });
    }
    function stripDetailText(rawHTML) {
        const parser = new DOMParser();
        const doc = parser.parseFromString(rawHTML, 'text/html');
        const bodyText = doc.body.innerText;
        let lines = bodyText.split('\n');

        const detailIdx = lines.findIndex(line => line.startsWith('Detail -'));
        if (detailIdx > -1) lines = lines.slice(detailIdx);

        const configPatterns = [
            /^Search Back:/, /^Search from/, /^Search From Time/, /^Reset Detail/,
            /^Use\/sample every/, /^Maximum number of records/, /^Format to display/,
            /^Data type to display/, /^Detail to display/, /^Show Errored\/Malformed/,
            /^\(\s*errored\/total\):/, /^Contact us/, /^Questions or comments\?/,
            /^About/, /^Notices/, /^Canada.gc.ca/, /^Visit Canada.gc.ca/
        ];
        lines = lines.filter(line => !configPatterns.some(pattern => pattern.test(line.trim())));

        let summaryFromText = '';
        lines = lines.filter(line => {
            if (line.startsWith('Summary From')) {
                summaryFromText = line.trim();
                return false;
            }
            return !line.startsWith('Number of reports used');
        });

        lines = lines.filter(line => !line.startsWith('Updated:'));

        console.log("Summary:", summaryFromText);
        return {
            cleanedText: lines.join('\n'),
            summaryFromText // or whatever format you're using

        };
    }
    function styleCloudDetail(floaterContent, summaryFromText = '') {

        const rawText = floaterContent.textContent;
        const cloudStart = rawText.indexOf('Detail - CLD');
        if (cloudStart === -1) return;
        const cloudBlock = rawText.slice(cloudStart);
        const lines = cloudBlock.split('\n').map(line => line.trim()).filter(Boolean);
        const summaryLineIndex = lines.findIndex(line => line.startsWith('Summary From'));
        if (summaryLineIndex !== -1) {
            summaryFromText = lines[summaryLineIndex];
        }
        const summaryStart = lines.findIndex(line => line.startsWith('Summary Type'));
        const samplingLines = lines.slice(3, summaryStart);
        const summaryLines = lines.slice(summaryStart + 1);

        // Determine detail type from URL
        const detailType = new URL(window.location.href).searchParams.get('detail') || 'Cloud';

        // Create container
        const detailContainer = document.createElement('div');
        detailContainer.id = 'awos-detail-container';

        if (summaryFromText) {
            const summaryHeader = document.createElement('div');
            summaryHeader.textContent = summaryFromText;
            summaryHeader.style.cssText = `
        font-weight: bold;
        font-size: 14px;
        margin: 12px 0 4px;
        padding: 4px 8px;
        background-color: #e8f0ff;
        border-left: 4px solid #4285f4;
      `;
            detailContainer.appendChild(summaryHeader);
        }

        // Add header to top of floater
        const floaterHeader = document.createElement('div');
        floaterHeader.textContent = `Detail – ${detailType.toUpperCase()}`;
        floaterHeader.style.cssText = `
          font-weight: bold;
          font-size: 16px;
          padding: 8px 12px;
          background-color: #f0f0f0;
          border-bottom: 1px solid #ccc;
        `;
        detailContainer.appendChild(floaterHeader);

        // Sampling Table
        const samplingTable = document.createElement('table');
        samplingTable.className = 'awos-cloud-table';
        samplingTable.innerHTML = `
          <thead>
            <tr><th>Stn</th><th>SP</th><th>Date</th><th>Time</th>
                <th>Layer 1</th><th>Layer 2</th><th>Layer 3</th>
                <th>Layer 4</th><th>Layer 5</th></tr>
          </thead>
          <tbody>
            ${samplingLines.map(line => {
                const parts = line.match(/(\w+)?\s*(\w{2})?\s*(\d{2})\s*(\d{2}:\d{2})\s*(.*?)$/);
                if (!parts) return '';
                const [_, stn, sp, dd, time, layers] = parts;
                const layerParts = layers.trim().split(/\s+/);
                while (layerParts.length < 5) layerParts.push('');
                return `<tr>
                <td>${stn || ''}</td><td>${sp || ''}</td><td>${dd}</td><td>${time}</td>
                ${layerParts.map(l => `<td>${l}</td>`).join('')}
              </tr>`;
            }).join('')}
          </tbody>
        `;

        // Summary Table
        const summaryTable = document.createElement('table');
        summaryTable.className = 'awos-summary-table';
        const summaryHeader = document.createElement('div');
        summaryHeader.textContent = summaryFromText || 'Hourly Summary';
        summaryHeader.style.cssText = `
          font-weight: bold;
          font-size: 14px;
          margin: 12px 0 4px;
          padding: 4px 8px;
          background-color: #e8f0ff;
          border-left: 4px solid #4285f4;
        `;
        summaryTable.innerHTML = `
          <thead>
            <tr><th>Type</th><th>Value</th><th>Unit</th><th>Stn</th><th>Date</th><th>Time</th></tr>
          </thead>
          <tbody>
            ${summaryLines.map(line => {
                const type  = line.slice(0, 18).trim();
                const value = line.slice(19, 28).trim();
                const unit  = line.slice(29, 33).trim();
                const stn   = line.slice(34, 44).trim();
                const dd    = line.slice(44, 50).trim();
                const time  = line.slice(50).trim();
                return `<tr>
                <td>${type}</td><td>${value}</td><td>${unit}</td>
                <td>${stn}</td><td>${dd}</td><td>${time}</td>
              </tr>`;
            }).join('')}
          </tbody>
        `;
        // Inject tables into container

        //blank placeholder for inital table header load
        if (summaryFromText) {
            const summaryHeader = document.createElement('div');
            detailContainer.appendChild(summaryHeader);
        }

        detailContainer.appendChild(samplingTable);
        if (summaryFromText) {
            const summaryHeader = document.createElement('div');
            summaryHeader.textContent = summaryFromText;
            summaryHeader.style.cssText = `
              font-weight: bold;
              font-size: 14px;
              margin: 12px 0 4px;
              padding: 4px 8px;
              background-color: #e8f0ff;
              border-left: 4px solid #4285f4;
            `;
            detailContainer.appendChild(summaryHeader);
        }
        detailContainer.appendChild(summaryTable);

        // Replace floater content
        floaterContent.innerHTML = '';
        floaterContent.appendChild(detailContainer);
    }
    function loadDetail(url) {
        fetch(url)
            .then(res => res.text())
            .then(html => {
                const updatedText = extractUpdatedTimestamp(html);
                localStorage.setItem(STORAGE_TIMESTAMP_KEY, updatedText);

                createPanel(updatedText);
                updateDetailTitleBar(updatedText, false)

                const { cleanedText, summaryFromText } = stripDetailText(html);

                const content = document.getElementById(CONTENT_ID);

                if (content) {
                    content.innerHTML = `<pre style="white-space: pre-wrap;">${cleanedText}</pre>`;
                    styleCloudDetail(content, summaryFromText);
                    saveDetailSnapshot(content);
                }
                localStorage.setItem(STORAGE_URL_KEY, url);
            });

    }
    function handleDetailClick(e) {
        const link = e.target.closest('a');
        if (!link || !link.href.includes('/AWOS/?id=') || !link.href.includes('&detail=')) return;

        e.preventDefault();
        e.stopImmediatePropagation();

        loadDetail(link.href);
    }

    document.addEventListener('click', handleDetailClick);

    restoreDebugPanel();
    restoreDetailSnapshot();
    restoreReportSnapshot();

})();

