// ==UserScript==
// @name         CFWOS Layout Enhancer 3
// @version      3.0e
// @description  Restore and enhance AWOS report layout with full styling
// @author       Chris
// @match        https://met.forces.gc.ca/*
// @grant        none
// ==/UserScript==

(function () {
  'use strict';

  let layoutApplied = false; // <-- guard flag

  function findAwosPanel() {
    // Align with Cleanup Suite’s detection targets
    return document.querySelector('#awos, #awos-panel, .awos-report, .report-panel, main');
  }

  function applyEnhancements(awosPanel) {
    // ... your existing styling code ...
    Object.assign(awosPanel.style, {
      backgroundColor: '#f5f5dc',
      color: '#222',
      padding: '24px',
      borderRadius: '10px',
      boxShadow: '0 2px 12px rgba(0,0,0,0.15)',
      fontFamily: '"Segoe UI", sans-serif',
      lineHeight: '1.6',
    });

    awosPanel.querySelectorAll('h1, h2, h3').forEach(header => {
      header.style.color = '#333';
      header.style.borderBottom = '1px solid #ccc';
      header.style.paddingBottom = '6px';
      header.style.marginTop = '20px';
    });

    const tables = awosPanel.querySelectorAll('table');
    tables.forEach(table => {
      Object.assign(table.style, {
        backgroundColor: '#fff',
        color: '#000',
        borderCollapse: 'collapse',
        width: '100%',
        marginTop: '20px',
        border: '1px solid #ccc',
      });

      const cells = table.querySelectorAll('th, td');
      cells.forEach(cell => {
        Object.assign(cell.style, {
          backgroundColor: '#fdf6e3',
          color: '#333',
          border: '1px solid #ccc',
          padding: '8px',
          textAlign: 'center',
        });
      });
    });

    const styleTag = document.createElement('style');
    styleTag.textContent = `
      @media (max-width: 768px) {
        #awos, #awos-panel, .awos-report, .report-panel, main {
          padding: 12px !important;
        }
        table { font-size: 14px !important; }
        h1, h2, h3 { font-size: 1.2em !important; }
      }
    `;
    document.head.appendChild(styleTag);
  }

  Logger.modules.whenReady(['core'], () => {
    Logger.modules.whenReady(['cleanup'], () => {
      if (layoutApplied) return; // <-- prevent double-run

      let attempts = 0;
      const maxAttempts = 20;
      const interval = 100;

      const tryEnhance = () => {
        if (layoutApplied) return; // <-- prevent re-entry mid-loop

        const awosPanel = findAwosPanel();
        if (awosPanel) {
          layoutApplied = true; // <-- mark as done
          Logger.info('🎨 Running Layout Enhancer after Cleanup');
          applyEnhancements(awosPanel);
          Logger.modules.register('layout');
          return;
        }

        attempts++;
        if (attempts <= maxAttempts) {
          setTimeout(tryEnhance, interval);
        } else {
          Logger.warn('⚠️ AWOS container not found after cleanup (tried 2s). Skipping layout.');
        }
      };

      tryEnhance();
    });
  });

})();

