// ==UserScript==
// @name         CFWOS Cleanup Suite
// @namespace    chris.awos
// @version      2.0e
// @description  UI fixes and enhancements for CFWOS, including AWOS restoration
// @match        https://met.forces.gc.ca/english/airops/*
// @grant        none
// ==/UserScript==


(function () {
    'use strict';

    (function waitForDependencies() {
        const waitForBody = setInterval(() => {
            if (document.body) {
                clearInterval(waitForBody);
                setTimeout(() => {
                  Logger.info("✅ Body detected — starting CleanupSuite");
                  Logger.log("Cleanup script started at", performance.now());
                  CleanupSuite.run();
                }, 500);
            }
        }, 50);
    })();

    Logger.modules.whenReady(['core'], () => {
      Logger.info("🧹 Running Cleanup Suite after Core");
      CleanupSuite.run();
      Logger.modules.register('cleanup');
    });

    const CleanupSuite = (() => {

      function purgeHeaderFooter() {
        Logger.group('Removing header and footer elements', () => {
            const selectors = [
                '#wb-lng', '#gcwu-sig', '#gcwu-gmap', '#gcwu-bnr', '#wb-srch', '#wb-bc',
                '#wb-sm', '#wb-sttl', '#wb-info', '#wb-sec', '#wb-bar', '#wb-glb-mn', '#wb-cont',
                'header', '#wb-nav', '#wb-foot', '#gcwu-foot', '#gcwu-date-mod', '#wb-srch-footer',
                '#wb-info-footer', '#wb-tphp', '#wb-dtmd', '#wb-ftr', 'footer'
            ];

            selectors.forEach(sel => {
                const el = document.querySelector(sel);
                if (el) {
                    Logger.log(`Removing ${sel}`, el);
                    el.remove();
                }
            });

            document.querySelectorAll('#wb-tphp a, .skip-links a').forEach(link => {
                const text = link.textContent.trim().toLowerCase();
                if (text.includes('skip to content') || text.includes('skip to institutional links')) {
                    Logger.log('Removing skip link', link);
                    link.remove();
                }
            });

            document.querySelectorAll('header, footer').forEach(el => {
                if (el.innerHTML.trim() === '') {
                    Logger.log('Removing empty container', el);
                    el.remove();
                }
            });
        });
    }
      function monitorFooterResurrection() {
        const interval = setInterval(() => {
            const footer = document.querySelector('footer, #wb-foot, #gcwu-foot');
            if (footer) {
                Logger.log('Footer reappeared — removing again', footer);
                footer.remove();
            }
        }, 500);
        setTimeout(() => clearInterval(interval), 5000);
    }

      function cleanupLegacy() {
          Logger.group('Legacy plugin and bloat cleanup', () => {
              const configScripts = Array.from(document.querySelectorAll('script')).filter(script =>
                  script.innerText.includes('djConfig','dojo','wet-boew','jquery')
              );

              Logger.group(`Removed ${configScripts.length} legacy config script(s)`, () => {
                  configScripts.forEach((script, i) => {
                      Logger.log(`Config Script ${i + 1}`, script);
                      script.remove();
                  });
              });

              const hiddenElements = [];

              Logger.group(`🧹 Evaluating and removing hidden/empty elements`, () => {
                const hiddenElements = [];
                const candidates = document.querySelectorAll('link, meta, input, img, script');

                Logger.group('📂 [AWOS] Element Details', () => {
                  let count = 0;

                  candidates.forEach((el) => {
                    // Skip anything inside the top bar
                    if (el.closest('#awos-top-bar')) return;

                    // Skip font-related links
                    if (el.tagName === 'LINK' && el.href && el.href.includes('fonts')) return;

                    const style = getComputedStyle(el);
                    const isHidden = style.display === 'none' || style.visibility === 'hidden';
                    const isEmpty = el.textContent.trim() === '' && el.children.length === 0;

                    if (isHidden && isEmpty) {
                      hiddenElements.push(el);
                      count++;

                      // 🎨 Styled header line
                      console.log(
                        `%c🟢 [AWOS] Element ${count}: <%c${el.tagName.toLowerCase()}%c>`,
                        'color: #00bfff; font-weight: bold;',
                        'color: #ff9800; font-weight: bold;',
                        'color: #00bfff; font-weight: bold;'
                      );

                      Logger.log('Display:', style.display);
                      Logger.log('Visibility:', style.visibility);
                      Logger.log('Text Content:', el.textContent.trim());
                      Logger.log('Children:', el.children.length);
                      Logger.log('Source:', el.src || el.href || '[inline]');
                      Logger.log('Hidden:', isHidden);
                      Logger.log('Empty:', isEmpty);
                      Logger.log('✅ Marked for removal');
                    }
                  });
                });

                Logger.group(`🗑️ Removed ${hiddenElements.length} hidden empty element(s)`, () => {
                  hiddenElements.forEach((el, i) => {
                    Logger.log(`Removed Element ${i + 1}`, el);
                    el.remove();
                  });
                });
              });

              Logger.log('Legacy cleanup complete ✅');
          });
      }

      function observeAWOS() {
        return new Promise(resolve => {
          const mutationLog = [];
          let layoutApplied = false;

          const waitForBody = setInterval(() => {
            if (document.body) {
              clearInterval(waitForBody);
              const observer = new MutationObserver(mutations => {

                mutations.forEach(mutation => mutationLog.push(mutation));
                clearTimeout(observer._debounce);

                observer._debounce = setTimeout(() => {
                  const awosPanel = document.querySelector('#awos, .awos-report, .report-panel, main');

                  if (awosPanel && !layoutApplied) {
                    clearTimeout(timeout); // cancel fallback
                    const mutationSummary = {
                      attributes: 0,
                      childList: 0,
                      subtree: 0,
                      characterData: 0
                    };

                    mutations.forEach(mutation => {
                      mutationSummary[mutation.type]++;
                    });

                    Logger.group(`${mutationLog.length} mutation(s) detected`, () => {
                      Logger.group('📂 Mutation Details',() => {
                          mutationLog.forEach((mutation, index) => {
                            Logger.log(`Mutation ${index + 1} [${mutation.type}]`);
                            Logger.log('Target:', mutation.target);
                            if (mutation.addedNodes.length) Logger.log('Added Nodes:', mutation.addedNodes);
                            if (mutation.removedNodes.length) Logger.log('Removed Nodes:', mutation.removedNodes);
                          });
                      });
                    });

                    if (mutationLog.length > 100) {
                      Logger.group('⚠️ Mutation Spike Alert', () => {
                        Logger.warn(`Spike detected: ${mutationLog.length} mutations`);
                        Logger.log(`Timestamp: ${new Date().toISOString()}`);
                        Logger.log('Sample mutated nodes:');
                        mutationLog.slice(0, 5).forEach((mutation, i) => {
                          Logger.log(`Mutation ${i + 1}:`, mutation.target);
                        });
                      });
                    }

                    purgeHeaderFooter();
                    monitorFooterResurrection();
                    cleanupLegacy();

                    if (!window.__awosCleanupDispatched) {
                      window.__awosCleanupDispatched = true;
                      window.dispatchEvent(new CustomEvent('AWOSCoreCleanupComplete'));
                      Logger.info('📢 Layout Enhancer dispatched successfully');
                    }

                    layoutApplied = true;

                    setTimeout(() => {
                      observer.disconnect();
                      Logger.info('observeAWOS Observer disconnected after delay');
                      resolve(); // ✅ Signal that observation and cleanup are complete
                    }, 300);
                  }
                }, 100);

              });
              observer.observe(document.body, { childList: true, subtree: true });
            }
          }, 10);

          const timeout = setTimeout(() => {

            Logger.info('[CleanupSuite] Report Viewer context detected — running cleanup via timeout fallback');

            purgeHeaderFooter();
            monitorFooterResurrection();
            cleanupLegacy();

            if (!window.__awosCleanupDispatched) {
              window.__awosCleanupDispatched = true;
              window.dispatchEvent(new CustomEvent('AWOSCoreCleanupComplete'));
              Logger.log('📢 Layout Enhancer dispatched via timeout fallback');
            }

            resolve();

          }, 3000); // fallback after 3 seconds
        });
      }

      function runCleanup(window, document) {
        "use strict";

        // ✅ Suppress ALL WET plugins
        const suppressedPlugins = [
            "wb-inview", "wb-mltmd", "wb-lbx", "wb-calevt",
            "wb-charts", "wb-twitter", "wb-zebra", "wb-txthl", "wb-toggle"
        ];

        suppressedPlugins.forEach(plugin => {
            document.addEventListener(`wb-init.${plugin}`, event => {
                event.stopImmediatePropagation();
                Logger.log("Suppressed plugin:", plugin);
            }, true); // useCapture = true to mimic jQuery's delegated binding
        });

        document.addEventListener("wb-init", event => {
            Logger.log("Plugin initialized:", event.namespace, event.target);
        }, true);

        // ✅ Prevent jQuery UI dialog/datepicker from initializing
        if (window.jQuery?.fn) {
            window.jQuery.fn.dialog = function () {
                Logger.warn("dialog() suppressed");
                return this;
            };
            window.jQuery.fn.datepicker = function () {
                Logger.warn("datepicker() suppressed");
                return this;
            };
        }

        // ✅ Safe Dojo widget cleanup
        if (window.dijit?.registry?.forEach) {
            dijit.registry.forEach(widget => {
                if (!widget.domNode || !widget.domNode.offsetParent) {
                    widget.destroyRecursive();
                    Logger.log("Destroyed unused Dojo widget:", widget.id);
                }
            });
        }

        // ✅ Patch legacy styles
        const style = document.createElement("style");
        style.textContent = `
        .wb-zebra tr:nth-child(even) { background: none !important; }
        [data-wb-lbx] { display: none !important; }
        table.wb-tables { border-collapse: collapse; width: 100%; }
        `;

        document.head.appendChild(style);

        // ✅ Cleanup hidden overlays
        setTimeout(() => {
            document.querySelectorAll('.wb-overlay').forEach(el => {
                if (el.offsetParent === null) {
                    el.remove();
                    Logger.log("Removed hidden overlay:", el.id);
                }
            });
        }, 3000);

        // ✅ Final report
        Logger.info("✅ AWOS Cleanup Suite complete");

      }

      return {
          run: async () => {

              await observeAWOS();

              runCleanup(window, document);
              Logger.log("Cleanup script finished", performance.now());

              Logger.info('[CleanupSuite] CFWOS Cleanup Suite complete.');

              window.dispatchEvent(new CustomEvent('CleanupSuiteComplete', {
                  detail: { timestamp: window.__suiteResponded }
              }));

          },
          observeAWOS: () => {
              observeAWOS();
          }
      };
  })();
})();
