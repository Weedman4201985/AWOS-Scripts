// ==UserScript==
// @name         CFWOS AWOS Core 8.2
// @version      8.2e
// @description  Edge Browser benchmark. Works best on edge
// @author       Chris
// @match        https://met.forces.gc.ca/english/airops/AWOS/*
// @grant        none
// @run-at       document-start
// ==/UserScript==
/*
───────────────────────────────────────────────
🧭 CFWOS AWOS Core 8.2 — System Flow Spec
───────────────────────────────────────────────

🚀 Phase 0 — Logger Core IIFE (first code to run)

  ** Critical dependency **
    All other scripts (Core logic, Cleanup Suite, Layout Enhancer, etc.)
    assume Logger exists. If this IIFE fails, the entire AWOS stack fails.
  ** Critical dependency **


  - Self-contained IIFE at very top of Core file
  - Defines global Logger object with:
    • Logger.info(), Logger.warn(), Logger.error()
    • Logger.log()
    • Logger.group()
    • Logger.perf()
    • Logger.perfWrap()
    • Logger.perfMark()
    • Logger.modules.register()
                    .whenReady()
  📢 Logging details:
    • Logger.info(): lifecycle milestones (UI suppression, injections, registry)
    • Logger.log(): detailed, granular debug/info (XHR, cookie access, mutation summaries)
    • Logger.warn(): duplicate module registration, skipped mutations
    • Logger.error():
    • Logger.group(): grouped console output
    • Logger.perf('start'/'stop', label): perf timing spans
    • Logger.perfWrap(fn, label): wraps a function with perf timing
    • Logger.perfMark(label): drop a named checkpoint
    • Logger.modules.register(name): Registers modules
                    .whenReady(deps, fn) listens for registered modules

  📦 Module system
    - register('core') after DOM ready
    - Other modules listen via Logger.modules.whenReady(['core'], ...)
    - Cleanup Suite signals completion by register('cleanup')
    - register() ignores duplicate names; whenReady() dedupes queued callbacks

🚀 Phase 1 — Early patch phase
  - Runs before DOMContentLoaded
  - waitForHeadAndInjectFavicon(): injects dummy favicon
  - patchZoom(): replaces CSS zoom with transform: scale
  - Optional patches: font block, cookie override, XHR logging
  - Logs patch summary via Logger

🧠 Phase 2 — DOM/UI setup (DOMContentLoaded)
- setupTopBar():
  • Creates manual top bar container with id #awos-top-bar
  • Defines “zones” (e.g., topLeft, topRight) for button placement
  • Appends to DOM early so observers can filter it out
- interceptMouseoverPopups(), findAllMouseoverElements(): UI helpers for AWOS hover elements
- Conditional UI suppression:
  • window.awosSuppressUI = (window.self !== window.top)
  • If suppressed: skip all UI injections
  • If not suppressed: inject full UI suite

📦 UI Injection Suite (if not suppressed)
1) **Auto-Refresh Toggle** (injectAutoRefreshToggle)
   - Persistent text node label (no DOM bloat)
   - setInterval tick every 1000 ms updates countdown
   - BroadcastChannel 'awos-refresh-sync' broadcasts {enabled, secondsLeft}
   - forcePageReload() when countdown hits 0 or on re-enable
   - Countdown mutations excluded from Cleanup observer via #awos-top-bar filter
2) **Report Viewer Button**
   - Opens stored AWOS report snapshots from localStorage
   - Restores state into viewer panel
3) **Debug Button**
   - Toggles debug logging and/or UI overlays
   - May expose extra Logger output for dev mode
4) **New Stations Button**
   - Opens station management UI
   - Allows adding/removing monitored stations
5) **Reset Floater Button**
   - Clears floater position/state from localStorage
   - Forces reinitialization on next load
- removeLegacyScripts() runs after UI injection to strip old AWOS scripts/styles

───────────────────────────────────────────────
*/
(function () {
                        /*
                        ─────────────────────────────────────────────
                        🧭 AWOS Logger Performance Legend — Core 8.x
                        ─────────────────────────────────────────────

                        Logger.perf('start', 'Label')     // Start stopwatch
                        Logger.perf('stop', 'Label')      // Stop and log elapsed time

                        Logger.perfWrap(fn, 'Label')      // Wrap function with perf timing

                          FUNCTION/METHOD EXAMPLE
                          const timedFn = Logger.perfWrap(myFunction, 'MyFunction');
                          timedFn();

                          Wrap it in an arrow function
                          Logger.perfWrap(() => runCleanup(window, document), 'runCleanup()')();

                          IIFE EXAMPLE:
                          Logger.perfWrap(function Core60() {...}, 'Core60')();

                        Logger.perfMark('Label')          // Drop a named checkpoint.
                                                          // Logs +Δ(delta) since last mark

                          Logger.perfMark('AWOS Init');   // Start of checkpoint
                          Logger.perfMark('AWOS Init');   // End of checkpoint.

                        🟢 Output:
                        ⏱️ [Label] start 123.456
                        🟢 [Label] finished — took 87.123 ms
                        📍 [Label] +120.500 ms since last mark

                        ─────────────────────────────────────────────
                        */
  'use strict';

  if (window.Logger) return;

  window.Logger = {
    log(...args) {
      console.log('🟢 %c[AWOS]', 'color: #00bfff; font-weight: bold;', ...args);
    },
    group(name, fn) {
      console.groupCollapsed(`📂 %c[AWOS] ${name}`, 'color: #00bfff; font-weight: bold;');
      try { fn(); } catch (e) {
        console.error('❌ Logger group error:', e);
      }
      console.groupEnd();
    },
    error(...args) {
      console.error('❌ %c[AWOS ERROR]', 'color: red; font-weight: bold;', ...args);
    },
    warn(...args) {
      console.warn('⚠️ %c[AWOS WARN]', 'color: orange; font-weight: bold;', ...args);
    },
    info(...args) {
      console.info('ℹ️ %c[AWOS INFO]', 'color: green; font-weight: bold;', ...args);
    },
    debug(...args) {
      if (window.AWOS_DEBUG) {
        console.debug('🐞 %c[AWOS DEBUG]', 'color: gray; font-weight: bold;', ...args);
      }
    },
    perf(action = 'start', overrideLabel = null, defaultLabel = 'Script') {
      let label = overrideLabel || defaultLabel;

      // Only try to auto-detect if no override provided
      if (!overrideLabel) {
        try {
          const err = new Error();
          const stackLines = err.stack.split('\n');

          // stackLines[0] = "Error"
          // stackLines[1] = "    at Logger.perf ..."
          // stackLines[2] = "    at FunctionName ..." or "    at Object.methodName ..."
          const callerLine = stackLines[2] || '';
          const match = callerLine.match(/at\s+(.*?)\s*\(/);
          if (match && match[1]) {
            label = match[1].trim();
          }
        } catch {
          // ignore, fallback to defaultLabel
        }
      }

      this._perfTimes = this._perfTimes || {};

      if (action.toLowerCase() === 'start') {
        this._perfTimes[label] = performance.now();
        this.log(`⏱️ [${label}] start ${this._perfTimes[label].toFixed(3)} ms`);
      }
      else if (action.toLowerCase() === 'stop') {
        const now = performance.now();
        let duration = now;

        if (this._perfTimes[label]) {
          duration = now - this._perfTimes[label];
          delete this._perfTimes[label];
        }
        this._perfTimes[label] = now;
        this.log(`🟢 [${label}] finished ${now.toFixed(3)} ms - took ${duration.toFixed(3)} ms`);
      }
      else {
        this.warn(`Logger.perf: Unknown action "${action}". Use "start" or "stop".`);
      }
    },
    perfWrap(fn, overrideLabel = null) {
      if (typeof fn !== 'function') {
        this.warn('Logger.perfWrap: First argument must be a function');
        return;
      }
      const label = overrideLabel || fn.name || 'anonymous';
      return (...args) => {
        this.perf('start', label);
        const result = fn.apply(this, args);
        if (result instanceof Promise) {
          return result.finally(() => this.perf('stop', label));
        }
        this.perf('stop', label);
        return result;
      };
    },
    perfTimeMark(label) {
      this._perfTimeMarks = this._perfTimeMarks || {};
      const now = performance.now();
      if (!this._perfTimeMarks[label]) {
        this._perfTimeMarks[label] = now;
        this.log(`📍 [${label}] time mark set at ${now.toFixed(3)} ms`);
      } else {
        const duration = now - this._perfTimeMarks[label];
        this.log(`📍 [${label}] +${duration.toFixed(3)} ms since last time mark`);
        this._perfTimeMarks[label] = now;
      }
    }

  };
  Logger.modules = {
    ready: {},
    queue: [],
    register(name) {
      if (this.ready[name]) {
        Logger.warn(`[AWOS] Module "${name}" already registered — ignoring duplicate.`);
        return;
      }
      this.ready[name] = true;
      Logger.log(`🟢 Module registered: ${name}`);

      if (this.queue[name]) {
        this.queue[name].forEach(cb => cb());
        delete this.queue[name];
      }
      // Check queued callbacks
      this.queue = this.queue.filter(({ deps, fn }) => {
        if (deps.every(dep => this.ready[dep])) {
          try {
            fn();
          } catch (e) {
            Logger.error(`Error running module callback for ${name}:`, e);
          }
          return false; // remove from queue
        }
        return true;
      });
    },
    whenReady(deps, fn) {
      if (deps.every(dep => this.ready[dep])) {
        fn();
      } else {
        this.queue.push({ deps, fn });
      }
    }
  };

  // --- Perf table collector ---
  const perfRecords = [];

  // Wrap existing perf
  const _origPerf = Logger.perf;
  Logger.perf = function (action = 'start', overrideLabel = null, defaultLabel = 'Script') {
    // Call the original logic (keeps auto-label + console output)
    _origPerf.call(this, action, overrideLabel, defaultLabel);

    // Also record for summary table
    const label = overrideLabel || defaultLabel;
    if (action.toLowerCase() === 'start') {
      perfRecords.push({ type: 'perf', label, start: performance.now(), end: null, duration: null });
    } else if (action.toLowerCase() === 'stop') {
      const rec = [...perfRecords].reverse().find(r => r.type === 'perf' && r.label === label && r.end === null);
      if (rec) {
        rec.end = performance.now();
        rec.duration = rec.end - rec.start;
      }
    }
  };

  // Wrap existing perfWrap
  const _origPerfWrap = Logger.perfWrap;
  Logger.perfWrap = function (fn, overrideLabel = null) {
    const label = overrideLabel || fn.name || 'anonymous';
    return _origPerfWrap.call(this, function (...args) {
      const start = performance.now();
      perfRecords.push({ type: 'perfWrap', label, start, end: null, duration: null });
      try {
        return fn.apply(this, args);
      } finally {
        const end = performance.now();
        const rec = [...perfRecords].reverse().find(r => r.type === 'perfWrap' && r.label === label && r.end === null);
        if (rec) {
          rec.end = end;
          rec.duration = rec.end - rec.start;
        }
      }
    }, label);
  };

  // Wrap existing perfMark
  const _origPerfTimeMark = Logger.perfTimeMark;
  Logger.perfTimeMark = function (label) {
    _origPerfTimeMark.call(this, label); // keep console output
    perfRecords.push({ type: 'perfTimeMark', label, time: performance.now() });
  };

  // Dump table after everything has loaded
  Logger.modules.whenReady(['core', 'cleanup', 'layout'], () => {
    Logger.info("📊 Dumping performance table after page load");

    if (perfRecords.length) {
      const filtered = perfRecords.filter((rec, idx, arr) => {
        if (rec.type === 'perf') {
          return !arr.some(r =>
            r.type === 'perfWrap' &&
            r.label === rec.label &&
            Math.abs((r.start || 0) - (rec.start || 0)) < 1
          );
        }
        return true;
      });

      const sorted = [...filtered].sort((a, b) => {
        const aTime = a.type === 'perfTimeMark' ? a.time : a.start;
        const bTime = b.type === 'perfTimeMark' ? b.time : b.start;
        return (aTime || 0) - (bTime || 0);
      });

      console.table(sorted.map(r => ({
        Type: r.type,
        Label: r.label,
        Start: r.start?.toFixed?.(2) || '',
        End: r.end?.toFixed?.(2) || '',
        Duration: r.duration ? r.duration.toFixed(2) + ' ms' : '',
        Time: r.type === 'perfTimeMark'
          ? r.time.toFixed(2) + ' ms'
          : ''
      })));
    }
  });

  Logger.info('🚀 AWOS Logger Utility v1.0 initialized');

})();

const REFRESH_INTERVAL = 60;
let suiteResponded = false;

if (localStorage.getItem('refreshEnabled') === null) {
    localStorage.setItem('refreshEnabled', 'false');
    Logger.log('[AWOS Core] Initialized refreshEnabled to false');
}

(function earlyPatch() {

    const ENABLE_INJECT_FAVICON = true
    const ENABLE_ZOOM_FIX = true;
    const ENABLE_FONT_BLOCK = true
    const ENABLE_COOKIE_OVERRIDE = true;
    const ENABLE_XHR_LOGGING = true;

    const earlyPatchReport = [];

    // 💉 Patch 1: Inject Favicon
    function waitForHeadAndInjectFavicon() {
        const inject = () => {
            const link = document.createElement('link');
            link.rel = 'icon';
            link.type = 'image/png';
            link.href = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8Xw8AAoMBgZkKXnUAAAAASUVORK5CYII=';
            document.head.appendChild(link);
            Logger.info('[AWOS Core] Dummy favicon injected safely');
        };
        const interval = setInterval(() => {
            if (document.head) {
              clearInterval(interval);
              inject();
            }
        }, 10);
          earlyPatchReport.push('💉 Favicon injection successfull');
    }

    // 🔍 Patch 2: Replace 'zoom' with 'transform: scale'
    function patchZoom() {
        const zoomElements = [...document.querySelectorAll('*')].filter(el => el.style.zoom);
        if (zoomElements.length === 0) {
            earlyPatchReport.push('🔕 Zoom Patch: No elements found using "zoom"');
            return;
        }

        zoomElements.forEach(el => {
            const zoomValue = el.style.zoom;
            el.style.transform = `scale(${zoomValue})`;
            el.style.transformOrigin = 'top left';
            el.style.zoom = '';
            console.log(`[Zoom Patch] Applied scale(${zoomValue}) to`, el);
        });

        earlyPatchReport.push(`✅ Zoom Patch: Applied to ${zoomElements.length} element(s)`);
    }

    // 🧼 Patch 3: Block legacy fonts
    function blockLegacyFonts() {
        const fontKeywords = ['Wingdings', 'Webdings', 'Symbol'];
        let patchedCount = 0;

        [...document.styleSheets].forEach(sheet => {
            try {
                [...sheet.cssRules].forEach(rule => {
                    if (rule.style?.fontFamily) {
                        fontKeywords.forEach(font => {
                            if (rule.style.fontFamily.includes(font)) {
                                rule.style.fontFamily = 'sans-serif';
                                patchedCount++;
                                console.log(`[Font Patch] Replaced ${font} with sans-serif`);
                            }
                        });
                    }
                });
            } catch (e) {
                    // Cross-origin stylesheet
            }
        });

        if (patchedCount === 0) {
            earlyPatchReport.push('🔕 Font Patch: No legacy fonts found');
        } else {
            earlyPatchReport.push(`✅ Font Patch: Replaced ${patchedCount} legacy font reference(s)`);
        }
    }

    // 🍪 Patch 4: Override document.cookie
    function overrideCookie() {
        try {
          Object.defineProperty(document, 'cookie', {
            configurable: true,
            get: function () {
              Logger.info('[Cookie Patch] Accessed cookies');
              return `metweb_settings=setting_norefresh&${REFRESH_INTERVAL}`;
            },
            set: function (val) {
              Logger.info('[Cookie Patch] Blocked cookie set:', val);
            }
          });

          earlyPatchReport.push('✅ Cookie Patch: Getter/setter overridden, REFRESH_INTERVAL set');
        } catch (e) {
          Logger.warn('[Cookie Patch] Failed to override document.cookie:', e);
          earlyPatchReport.push('⚠️ Cookie Patch: Override failed');
      }
    }

    // 📡 Patch 5: Log all XHR requests
    function logXHR() {
            const originalOpen = XMLHttpRequest.prototype.open;
            XMLHttpRequest.prototype.open = function (...args) {
                Logger.log('[XHR Patch] Request:', args);
                return originalOpen.apply(this, args);
            };

            const originalSend = XMLHttpRequest.prototype.send;
            XMLHttpRequest.prototype.send = function (...args) {
                if (this.async === false) {
                    Logger.warn('[XHR Patch] ⚠️ Synchronous XHR detected:', this);
                }
                return originalSend.apply(this, args);
            };

            earlyPatchReport.push('✅ XHR Patch: Logging enabled for all requests');
        }

    // ✅ Final report
    Logger.info('⚙️ Running early Patches...');

    if (ENABLE_COOKIE_OVERRIDE) overrideCookie();
    if (ENABLE_INJECT_FAVICON) waitForHeadAndInjectFavicon();
    if (ENABLE_ZOOM_FIX) patchZoom();
    if (ENABLE_FONT_BLOCK) blockLegacyFonts();
    if (ENABLE_XHR_LOGGING) logXHR();

    Logger.group('📊 Patch Table', () => {
      console.table(earlyPatchReport);
    });

    Logger.info('✅ Early patch is complete and table generated');

})();

(function () {
    'use strict';

    const buttonStyle = `
      padding: 6px 12px;
      font-size: 13px;
      background: #007bff;
      color: #fff;
      border: none;
      border-radius: 4px;
      cursor: pointer;
      font-family: "Segoe UI", sans-serif;
      box-shadow: rgba(0, 0, 0, 0.15) 0px 1px 4px;
      white-space: nowrap;
      flex: 0 0 auto;
    `;

    function getPanelKeys(panelType) {
      return {
        urlKey: `${panelType}-url`,
        snapshotKey: `${panelType}-snapshot`,
        timestampKey: `${panelType}-timestamp`,
        positionKey: `${panelType}-position`,
        sizeKey: `${panelType}-size`
      };
    }
    function getLatestHourlyTimestamp() {
      const now = new Date();
      now.setUTCMinutes(0, 0, 0); // snap to top of the hour
      const pad = (n) => n.toString().padStart(2, '0');
      return `${now.getUTCFullYear()}${pad(now.getUTCMonth() + 1)}${pad(now.getUTCDate())}${pad(now.getUTCHours())}00`;
    }
    function injectFakeRefreshMeta(intervalSeconds = 60) {
      let meta = document.querySelector('meta[http-equiv="refresh"]');
      if (!meta) {
        meta = document.createElement('meta');
        meta.setAttribute('http-equiv', 'refresh');
        document.head.appendChild(meta);
      }
      meta.setAttribute('content', `${intervalSeconds}`);
    }
    function disableAwosAutoRefresh() {

      document.querySelectorAll('meta[http-equiv="refresh"]').forEach(m => m.remove());

      window.location.reload = () => console.log('[AWOS] reload blocked');
      window.location.replace = () => console.log('[AWOS] replace blocked');

      const realSetTimeout = window.setTimeout;
      const realSetInterval = window.setInterval;

      window.setTimeout = function(fn, delay, ...args) {
        if (typeof fn === 'string' && /reload|replace/i.test(fn)) return 0;
        return realSetTimeout(fn, delay, ...args);
      };
      window.setInterval = function(fn, delay, ...args) {
        if (typeof fn === 'string' && /reload|replace/i.test(fn)) return 0;
        return realSetInterval(fn, delay, ...args);
      };

      for (let i = 0; i < 1000; i++) {
        clearTimeout(i);
        clearInterval(i);
      }
    }
    function forcePageReload() {
          window.onbeforeunload = null;
          window.onunload = null;
          window.location.reload(); // ✅ standard reload
          //location.href = location.href;
    }

    function extractAwosStations() {
      const checkboxes = document.querySelectorAll('input[type="checkbox"][name="id"]');
      const stations = [];

      checkboxes.forEach(cb => {
        const icao = cb.value?.trim();
        const label = cb.nextElementSibling?.textContent?.trim();
        if (icao && /^[A-Z]{4}$/.test(icao)) {
          stations.push({
            icao,
            label,
            url: `https://met.forces.gc.ca/english/airops/AWOS/?id=${icao}`
          });
        }
      });

      return stations;
    }

    function setupTopBar() {

      const DEBUG_MODE = false;

      if (window.awosSuppressUI) {
        Logger.log('[AWOS Core] Top bar injection suppressed.');
        return null;
      }

      let topBar = document.querySelector('#awos-top-bar');

      if (!topBar) {
        topBar = document.createElement('div');
        topBar.id = 'awos-top-bar';
        topBar.style.cssText = `
          position: sticky;
          top: 0;
          z-index: 1000;
          display: flex;
          flex-direction: column;
          align-items: stretch;
          padding: 10px;
          background: #f8f8f8;
          border-bottom: 1px solid #ccc;
          gap: 6px;
        `;

        if (topBar) {
          topBar.style.fontFamily = '"Segoe UI", sans-serif';
        }

        // Title row
        const topTitleRow = document.createElement('div');
        topTitleRow.id = 'awos-top-title-row';
        topTitleRow.style.cssText = `
          display: flex;
          justify-content: space-between;
          align-items: center;
        `;

        const topTitleZone = document.createElement('div');
        topTitleZone.id = 'awos-top-title-zone';
        topTitleZone.style.cssText = `
          margin: 0;
          display: flex;
          font-size: 20px;
          font-weight: bold;
          text-align: center;
          flex-direction: column;
          justify-content: center;
          align-items: center;
          gap: 6px;
        `;

        const title = document.querySelector('main h1');
        if (title) {
          title.style.margin = '0';
          title.style.marginLeft = '13px'; // Try 4px, 6px, or 8px depending on your eye test
          title.style.borderBottom = 'none';
          title.style.color = '#333';
          title.style.fontSize = '25px';
          title.style.fontWeight = 'bold';
          title.style.textAlign = 'center';
          title.style.width = 'auto';
          title.style.flex = '0 0 auto';


        }

        // Top Button row
        const topButtonRow = document.createElement('div');
        topButtonRow.id = 'awos-top-button-row';
        topButtonRow.style.cssText = `
          display: flex;
          justify-content: space-between;
          align-items: center;
          gap: 10px;
        `;

        const topCenterZone = document.createElement('div');
        topCenterZone.id = 'awos-top-center-zone';
        topCenterZone.style.cssText = `
          display: flex;
          justify-content: center;
          align-items: center;
          width: 33%;
        `;

        if(DEBUG_MODE) {
          topCenterZone.style.border = '3px dashed red';
        };

        const topLeftZone = document.createElement('div');
        topLeftZone.id = 'awos-top-left-zone';
        topLeftZone.style.cssText = 'display: flex; gap: 10px; justify-content: flex-start; width: 33%;';
        if (DEBUG_MODE) {
          topLeftZone.style.border = '3px dashed red';
        };

        const topRightZone = document.createElement('div');
        topRightZone.id = 'awos-top-right-zone';
        topRightZone.style.cssText = 'display: flex; gap: 10px; justify-content: flex-end; width: 33%;';
        if (DEBUG_MODE) {
          topRightZone.style.border = '3px dashed red';
        };



        // Bottom row: Button zones
        const bottomRow = document.createElement('div');
        bottomRow.id = 'awos-bottom-row';
        bottomRow.style.cssText = `
          display: flex;
          justify-content: space-between;
          align-items: center;
          gap: 10px;
        `;

        const bottomCenterZone = document.createElement('div');
        bottomCenterZone.id = 'awos-bottom-center-zone';
        bottomCenterZone.style.cssText = `
          display: flex;
          flex-direction: column;
          align-items: center;
          width: 33%;
        `;
        if (DEBUG_MODE){
          bottomCenterZone.style.border = '3px dashed blue';
        };

        const bottomLeftZone = document.createElement('div');
        bottomLeftZone.id = 'awos-bottom-left-zone';
        bottomLeftZone.style.cssText = 'display: flex; gap: 10px; justify-content: flex-start; width: 33%;';
        if (DEBUG_MODE){
          bottomLeftZone.style.border = '3px dashed blue';
        }

        const bottomRightZone = document.createElement('div');
        bottomRightZone.id = 'awos-bottom-right-zone';
        bottomRightZone.style.cssText = 'display: flex; gap: 10px; justify-content: flex-end; width: 33%;';
        if (DEBUG_MODE){
          bottomRightZone.style.border = '3px dashed blue';
        };

        topCenterZone.appendChild(title);

        topTitleRow.appendChild(topLeftZone);
        topTitleRow.appendChild(topCenterZone);
        topTitleRow.appendChild(topRightZone);

        bottomRow.appendChild(bottomLeftZone);
        bottomRow.appendChild(bottomCenterZone);
        bottomRow.appendChild(bottomRightZone);

        topBar.appendChild(topTitleRow);
        topBar.appendChild(topButtonRow);
        topBar.appendChild(bottomRow);

        document.body.prepend(topBar);
      }

      return topBar;
    }
    function getTopBarZone(side = 'bottomRight') {
      const zones = {

        topLeft: document.querySelector('#awos-top-left-zone'),
        topCenter: document.querySelector('#awos-top-center-zone'),
        topRight: document.querySelector('#awos-top-right-zone'),

        bottomLeft: document.querySelector('#awos-bottom-left-zone'),
        bottomCenter: document.querySelector('#awos-bottom-center-zone'),
        bottomRight: document.querySelector('#awos-bottom-right-zone')

      };
      return zones[side] || zones.right;
    }

    function styleButton(btn, bgColor, overrides = {}) {
      Object.assign(btn.style, {
        padding: '6px 12px',
        fontSize: '13px',
        color: '#fff',
        border: 'none',
        borderRadius: '4px',
        cursor: 'pointer',
        fontFamily: '"Segoe UI", sans-serif',
        boxShadow: 'rgba(0, 0, 0, 0.15) 0px 1px 4px',
        whiteSpace: 'nowrap',
        flex: '0 0 auto',
        background: bgColor,
        ...overrides // apply custom styles
      });
    }

    function injectAutoRefreshToggle(side = 'bottomLeft') {
      const STORAGE_KEY = 'awosAutoRefreshEnabled';
      let refreshEnabled = localStorage.getItem(STORAGE_KEY) !== 'false';
      let secondsLeft = REFRESH_INTERVAL;

      const zone = getTopBarZone(side);
      const toggleBtn = document.createElement('button');

      // Create a persistent text node for the label
      const labelNode = document.createTextNode('');
      toggleBtn.appendChild(labelNode);

      function updateButtonLabel() {
        // Just update the text node's value instead of replacing it
        labelNode.nodeValue = `⏳ Auto-Refresh: ${refreshEnabled ? 'ON' : 'OFF'} (${secondsLeft}s)`;

        styleButton(toggleBtn, refreshEnabled ? '#0078D4' : '#ffef08', {
          color: refreshEnabled ? '#ffffff' : '#000000'
        });
      }

      toggleBtn.addEventListener('click', () => {
        const wasDisabled = !refreshEnabled;
        refreshEnabled = !refreshEnabled;
        localStorage.setItem(STORAGE_KEY, refreshEnabled);

        Logger.info(`[AWOS Core] Auto-refresh ${refreshEnabled ? 'enabled' : 'disabled'} by user`);
        updateButtonLabel();

        if (wasDisabled && refreshEnabled) {
          Logger.info(`[AWOS Core] Auto-refresh re-enabled — refreshing immediately`);
          forcePageReload();
        }
      });

      zone.appendChild(toggleBtn);
      Logger.info(`Auto-Refresh button successfully added to ${side}`);
      updateButtonLabel();

      setInterval(() => {
        if (refreshEnabled) {
          secondsLeft--;
          if (secondsLeft <= 0) {
            Logger.log(`[AWOS Core] Auto-refresh triggered at ${new Date().toLocaleTimeString()}`);
            forcePageReload();
          }
        } else {
          secondsLeft = REFRESH_INTERVAL;
        }
        updateButtonLabel();
      }, 1000);

      window.getAwosRefreshStatus = () => ({ enabled: refreshEnabled, secondsLeft });
      window.triggerAwosRefresh = () => forcePageReload();

      const bc = new BroadcastChannel('awos-refresh-sync');
      setInterval(() => {
        bc.postMessage({ enabled: refreshEnabled, secondsLeft });
      }, 1000);

      Logger.info(`Auto-refresh module initialized. Current state: ${refreshEnabled ? 'ON' : 'OFF'}`);
    }
    function injectReportViewerButton(side = 'bottomRight') {
      const zone = getTopBarZone(side);
      const viewerBtn = document.createElement('button');
      viewerBtn.textContent = '📊 Report Viewer';
      viewerBtn.className = 'awos-btn';
      viewerBtn.style.cssText = `
        padding: 6px 12px;
        font-size: 13px;
        background: #0078D4;
        color: #fff;
        border: none;
        border-radius: 6px;
        cursor: pointer;
        font-family: "Segoe UI", sans-serif;
        box-shadow: rgba(0, 0, 0, 0.15) 0px 1px 4px;
        white-space: nowrap;
        flex: 0 0 auto;
      `;

      viewerBtn.addEventListener('click', () => {

        if (typeof window.openReportViewer === 'function') {
          window.openReportViewer();
        } else {
          console.warn('[AWOS Core] openReportViewer() is not available.');
        }

      });

      zone.appendChild(viewerBtn);
      Logger.info(`Report Viewer button successfully added to ${side}`);

    }
    function injectDebugButton(side = 'topLeft') {
      const zone = getTopBarZone(side);
      const debugBtn = document.createElement('button');
      debugBtn.textContent = '🧪 Debug';

      styleButton(debugBtn, '#000', {
        color: '#00ff00',
        fontFamily: 'monospace',
        fontWeight: 'bold'
      });

      debugBtn.addEventListener('click', () => {

        if (typeof window.openDebugPanel === 'function') {
          window.openDebugPanel();
        } else {
          console.warn('[AWOS Core] openDebugPanel() is not available.');
        }

      });

      zone.appendChild(debugBtn);
      Logger.info(`Debug button successfully added to ${side}`)
    }
    function injectResetFloaterButton(side = 'topRight') {
      const zone = getTopBarZone(side);
      const resetBtn = document.createElement('button');
      resetBtn.textContent = '🧹 Reset Floater';

      styleButton(resetBtn, '#cc0000');

      resetBtn.onclick = () => {
        const confirmReset = confirm('Are you sure you want to reset the floater?\nThis will clear its position, size, and ALL Snapshots.');
        if (!confirmReset) return;

        // Remove all known panel types
        const panelTypes = ['detail', 'report', 'debug','selector-panel'];
        panelTypes.forEach(type => {
          const { snapshotKey, urlKey, timestampKey, positionKey, sizeKey } = getPanelKeys(type);
          [snapshotKey, urlKey, timestampKey, positionKey, sizeKey].forEach(key => localStorage.removeItem(key));
        });

        // Clear legacy/global keys
        [
          'last-detail-url',
          'last-panel-snapshot',
          'last-timestamp',
          'debug-snapshot',
          'debug-active',
          'debug-style',
          'report-html',
          'report-active',
          'selector-active'

        ].forEach(key => localStorage.removeItem(key));

        // Reset spawn flags
        window.__awosReportViewerSpawned = false;

        // Reload the page to apply reset
        location.reload();
      };

      zone.appendChild(resetBtn);
      Logger.info(`Reset Floater button successfully added to ${side}`);
    }

    /*function injectNewStationsButton(side = 'bottomCenter'){
      const zone = getTopBarZone(side);
      const newStationsBtn = document.querySelector('#base_id');
      newStationsBtn.textContent = 'New Stations';
      newStationsBtn.className = 'awos-btn';

      styleButton(newStationsBtn, '#28a745', {
        marginLeft: '24px' // adjust this value as needed
      });

      newStationsBtn.onclick = () => {
        if (typeof window.renderAwosSelectorPanel === 'function') {
          window.renderAwosSelectorPanel();
        } else {
          Logger.warn('[AWOS Core] renderAwosSelectorPanel is not available.');
        }
      };


      zone.appendChild(newStationsBtn);
      Logger.info(`New Stations button successfully added to ${side}`)

    }*/

    /*function injectNewStationsButton(side = 'bottomCenter') {
        const zone = getTopBarZone(side);
        const newStationsBtn = document.querySelector('#base_id');

        if (!newStationsBtn) {
            Logger.warn('[AWOS Core] Could not find #base_id button to modify.');
            return;
        }

        newStationsBtn.textContent = 'New Stations';
        newStationsBtn.className = 'awos-btn';

        styleButton(newStationsBtn, '#28a745', {
            marginLeft: '24px'
        });

        // Wait until renderAwosSelectorPanel is defined before binding
        function bindWhenReady() {
            if (typeof window.renderAwosSelectorPanel === 'function') {
                newStationsBtn.onclick = () => {
                    Logger.info('[AWOS Core] Opening AWOS Selector Panel...');
                    window.renderAwosSelectorPanel();
                };
                Logger.info('[AWOS Core] New Stations button bound to renderAwosSelectorPanel');
            } else {
                Logger.warn('[AWOS Core] renderAwosSelectorPanel not ready yet, retrying...');
                setTimeout(bindWhenReady, 250); // retry every 250ms until available
            }
        }

        bindWhenReady();

        zone.appendChild(newStationsBtn);
        Logger.info(`New Stations button successfully added to ${side}`);
    }*/

    function injectNewStationsButton(side = 'bottomCenter') {
        const zone = getTopBarZone(side);
        const newStationsBtn = document.querySelector('#base_id');

        if (!newStationsBtn) {
            Logger.warn('[AWOS Core] Could not find #base_id button to modify.');
            return;
        }

        newStationsBtn.textContent = 'New Stations';
        newStationsBtn.className = 'awos-btn';

        styleButton(newStationsBtn, '#28a745', { marginLeft: '24px' });

        let attempts = 0;
        const maxAttempts = 20; // retry for ~5 seconds at 250ms intervals

        function bindWhenReady() {
            if (typeof window.renderAwosSelectorPanel === 'function') {
                newStationsBtn.onclick = () => {
                    Logger.info('[AWOS Core] Opening AWOS Selector Panel...');
                    window.renderAwosSelectorPanel();
                };
                Logger.info('[AWOS Core] New Stations button bound to renderAwosSelectorPanel');
            } else if (attempts < maxAttempts) {
                attempts++;
                setTimeout(bindWhenReady, 250);
            } else {
                Logger.warn('[AWOS Core] renderAwosSelectorPanel not found after waiting.');
            }
        }

        bindWhenReady();
        zone.appendChild(newStationsBtn);
        Logger.info(`New Stations button successfully added to ${side}`);
    }

    function findAllMouseoverElements() {
      const elements = Array.from(document.querySelectorAll('[onmouseover]'));
      Logger.info(`[findAllMouseoverElements] Found ${elements.length} elements with onmouseover`);
      return elements;
    }
    function interceptMouseoverPopups() {
        const elements = findAllMouseoverElements();

        elements.forEach((el, index) => {
            const originalHandler = el.getAttribute('onmouseover');
            el.removeAttribute('onmouseover');

            let tooltip = null;
            let showTimer = null;
            let hideTimer = null;

            const handleMouseMove = (e) => {
                if (tooltip) {
                    const mouseX = e.clientX + window.scrollX;
                    const mouseY = e.clientY + window.scrollY;
                    tooltip.style.top = `${mouseY + 12}px`;
                    tooltip.style.left = `${mouseX + 12}px`;
                }
            };

            const showTooltip = (e) => {
                Logger.log(`[interceptMouseoverPopups] Pointer entered element #${index}`);
                clearTimeout(hideTimer);

                if (tooltip) {
                    tooltip.remove();
                    tooltip = null;
                    document.removeEventListener('mousemove', handleMouseMove);
                }

                showTimer = setTimeout(() => {
                    tooltip = createTooltip(el);
                    document.body.appendChild(tooltip);
                    document.addEventListener('mousemove', handleMouseMove);
                }, 100);
            };

            const hideTooltip = () => {
                clearTimeout(showTimer);

                if (tooltip) {
                    hideTimer = setTimeout(() => {
                        tooltip.remove();
                        tooltip = null;
                        document.removeEventListener('mousemove', handleMouseMove);
                    }, 2000);
                }
            };

            el.addEventListener('pointerenter', showTooltip);
            el.addEventListener('pointerleave', hideTooltip);
        });
    }
    function createTooltip(el) {
        const epoch = parseInt(el.dataset.epochvalue, 10);
        const offset = parseInt(el.dataset.tzoffset, 10) * 60; // minutes to seconds
        const adjustedTime = new Date((epoch + offset) * 1000);

        const estTime = new Intl.DateTimeFormat('en-US', {
            timeZone: 'America/New_York',
            year: 'numeric',
            month: 'long',
            day: 'numeric',
            hour: '2-digit',
            minute: '2-digit',
            second: '2-digit',
            hour12: true
        }).format(adjustedTime);

        const tooltip = document.createElement('div');
        tooltip.textContent = `EST Time: ${estTime}`;
        tooltip.style.position = 'absolute';
        tooltip.style.background = '#222';
        tooltip.style.color = '#fff';
        tooltip.style.padding = '6px 10px';
        tooltip.style.borderRadius = '6px';
        tooltip.style.fontSize = '14px';
        tooltip.style.pointerEvents = 'none';
        tooltip.style.zIndex = '9999';

        return tooltip;
    }

    function isLegacyScript(script) {
        const src = script.src || '';
        return [
            'wet-boew/jquery.min.js',
            'jquery-ui.min.js',
            'jquery.ui.touch-punch.min.js',
            'jquery-ui-slider-pips.js',
            'wet-boew/js/wet-boew.min.js',
            'common_jquery.js',
            'wet-boew/js/i18n/en.min.js'
        ].some(fragment => src.includes(fragment));
    }
    function removeLegacyScripts() {
      const legacyScripts = Array.from(document.querySelectorAll('script')).filter(isLegacyScript);

      Logger.group(`🧨 Removed ${legacyScripts.length} legacy script(s)`, () => {
        legacyScripts.forEach((script, i) => {
          Logger.log(`Legacy Script ${i + 1}`, script.src || '[inline script]');
          script.remove();
        });
      });
    }

    function waitForBody(callback) {
      if (document.body) {
          callback();
      } else {
          const interval = setInterval(() => {
              if (document.body) {
                  clearInterval(interval);
                  callback();
              }
          }, 10);
      }
  }
    function waitForLayout(callback) {
        const interval = setInterval(() => {
            const panel = document.querySelector('#awos, .report-panel, main');
            if (panel) {
                clearInterval(interval);
                callback();
            }
        }, 50);
    }
    function waitForsetupTopBar(callback) {
      const interval = setInterval(() => {
        if (typeof setupTopBar === 'function') {
          clearInterval(interval);
          callback();
        }
      }, 50);
    }

    (function Core60() {
        Logger.perf('start','Core60');
        Logger.info('✅ Starting AWOS Core...');
        document.cookie = `metweb_settings=setting_norefresh&${REFRESH_INTERVAL}`;
        window.awosSuppressUI = window.self !== window.top;
        Logger.info(`[AWOS Core] UI Suppression: ${window.awosSuppressUI ? 'ON (iframe)' : 'OFF (main window)'}`);
        window.addEventListener('DOMContentLoaded', () => {
          setupTopBar();
          interceptMouseoverPopups();
          if (!window.awosSuppressUI) {
            injectAutoRefreshToggle('bottomLeft');
            injectReportViewerButton('bottomRight');
            injectDebugButton('topLeft');
            injectNewStationsButton('bottomCenter');
            injectResetFloaterButton('topRight');
            removeLegacyScripts();
            Logger.info('🧭 DOM fully loaded');
          }
          Logger.perf('stop','Core60')
          Logger.modules.register('core');
        });
    })();
})();